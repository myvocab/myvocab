PHP_Text2Speech
===============

This class can generate speech audio to say a given text.

It can send a HTTP request to the Google Translate API to say a given text.

The class downloads the speech audio in MP3 format and stores it in a given file.
